This module forbids adding empty order lines on POS orders.

When clicking on the "Payment" button in the Point of Sale,
a popup is shown if product quantity for one or more order
lines is set to 0.
